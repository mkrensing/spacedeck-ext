

let link = constructSpacedeckModule("link");
link.loadStylesheets("link.css");

link.ready(function() {

    console.log("Custom Link loaded");

});